# Рулетка CPARIP / WheelSpin

Колесо, результат и открытие формы.

Скопируйте ywbroulette.js, ywbroulette.css и prizewheel.png. Подключите CSS в <head>, JS после HTML контейнеров.

Создайте отдельные #roulette и #roulette-form. Вызовите initRoulette({ selectors: { roulette: "#roulette", form: "#roulette-form" } }).

Тексты задаются в texts, длительность в duration (мс), изображение в image. onResult вызывается после вращения, onComplete после подтверждения. Возвращаемый объект содержит state, spin() и destroy().

stopAngle задаёт финальный угол. Текст результата должен соответствовать выбранному сектору изображения. По умолчанию это заданная скидка, не случайный розыгрыш.

Запуск: откройте index.html через локальный HTTP-сервер. Отправка форм заблокирована demo-common.js. Для рабочего лендинга подключите свой обработчик и удалите демонстрационный перехват.

stopAngle задаёт сектор остановки. Текст результата должен соответствовать выбранному сектору; пример не является случайным розыгрышем.

https://github.com/dvygolov/YWB.Roulette.JS
https://cpa.rip/stati/roulette-script/
