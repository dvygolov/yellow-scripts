# YTDefer

Ленивая загрузка YouTube по клику на превью.

Создайте блок `.ytdefer` с `data-src` — идентификатором ролика YouTube. Задайте блоку ширину и `aspect-ratio: 16/9`.

Подключите `ytdefer.min.js` и вызовите `ytdefer_setup()`. API плеера загружается только после клика.

В примере `data-poster="poster.jpg"` задаёт локальное превью. Без него используется изображение с YouTube.

Запуск: откройте index.html через локальный HTTP-сервер. Отправка форм заблокирована demo-common.js. Для рабочего лендинга подключите свой обработчик и удалите демонстрационный перехват.



https://github.com/groupboard/ytdefer
https://t.me/yellow_web/504
