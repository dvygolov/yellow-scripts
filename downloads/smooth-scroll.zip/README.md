# Плавная прокрутка и починка якорей

Переход к форме или выбранному блоку без перезагрузки.

Укажите ссылке якорь формы, например `href="#order"`, а форме — `id="order"`.

В обработчике клика вызовите `document.querySelector("#order").scrollIntoView({behavior: "smooth"})`.

Запуск: откройте index.html через локальный HTTP-сервер. Отправка форм заблокирована demo-common.js. Для рабочего лендинга подключите свой обработчик и удалите демонстрационный перехват.



https://gist.github.com/dvygolov/75270c5e57a1b0dc0f6e6402206bb8d7
https://github.com/dvygolov/YellowTDS/blob/multipleconfigs/code/scripts/fixanchors.js
https://t.me/yellow_web/297
