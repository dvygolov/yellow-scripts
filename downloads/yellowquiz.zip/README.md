# YellowQuiz

Пошаговый квиз, настраиваемый структурой вопросов и ответов.

Подключите `ywbquiz.css` и `ywbquiz.js`. Создайте `<div id="quiz"></div>`.

Вызовите `initQuiz({divId: "quiz", questions: [...]})`. Вопрос содержит `title`, `subtitle`, `image`, `answers`; ответ содержит `text` и при необходимости `image`.

Последний вопрос без `answers` является результатом. Цвета задаются в `quizColor` и `answersColor`; полный вызов показан в `index.html`.

Запуск: откройте index.html через локальный HTTP-сервер. Отправка форм заблокирована demo-common.js. Для рабочего лендинга подключите свой обработчик и удалите демонстрационный перехват.



https://github.com/dvygolov/YWB.YellowQuiz.JS
https://t.me/yellow_web/363
