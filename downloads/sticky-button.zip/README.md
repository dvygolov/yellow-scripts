# Плавающая кнопка заказа

Закреплённая кнопка перехода к форме.

Поместите форму с `id="orderBlock"` в нужное место страницы. Добавьте `.sticky-order` со ссылкой `href="#orderBlock"`.

Перенесите CSS `.sticky-order`; `position: fixed` удерживает кнопку внизу окна. `scroll-behavior: smooth` обеспечивает плавный возврат. Оставьте нижний отступ, чтобы кнопка не закрывала содержимое.

Запуск: откройте index.html через локальный HTTP-сервер. Отправка форм заблокирована demo-common.js. Для рабочего лендинга подключите свой обработчик и удалите демонстрационный перехват.



https://gist.github.com/dvygolov/72056329981d987321aebb0e54d3a5bf
https://codepen.io/dvygolov/pen/xxLJmrN
https://t.me/yellow_web/542
