# Витрина Carousel

Встраиваемая витрина для домонетизации.

Подключите jQuery, `slick.css`, `slick-theme.css` и `slick.min.js`. Создайте `.carousel` с элементами слайдов.

Вызовите `$(".carousel").slick({slidesToShow: 3, dots: true, responsive: [...]})`. Полная мобильная настройка находится в `index.html`.

Запуск: откройте index.html через локальный HTTP-сервер. Отправка форм заблокирована demo-common.js. Для рабочего лендинга подключите свой обработчик и удалите демонстрационный перехват.



https://github.com/dvygolov/carousel
