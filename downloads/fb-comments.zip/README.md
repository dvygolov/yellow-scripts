# FB Comments

Вёрстка блока комментариев в стиле Facebook.

Подключите `comments-demo.css`, затем `comments-config.js` и создайте контейнер `#comments`.

Вызовите `initComments({selector: "#comments", storageKey: "my-comments", users: [...], comments: [...]})`. Полный конфиг находится во вкладке «Код», файл `example.js`.

Пользователь: `id`, `name`, `avatar`. Комментарий: `id`, `userId`, `parentId`, `text`, `date` в формате ISO. Для верхнего уровня используйте `parentId: null`.

Используйте уникальный `storageKey` для каждой ленты. Сортировка переставляет ветки целиком; ответы остаются под родителями.

Запуск: откройте index.html через локальный HTTP-сервер. Отправка форм заблокирована demo-common.js. Для рабочего лендинга подключите свой обработчик и удалите демонстрационный перехват.

Новые комментарии сохраняются только в этом браузере. Другие посетители их не видят. При недоступном хранилище ввод работает до закрытия страницы.

https://github.com/dvygolov/yellow-scripts/tree/main/demos/fb-comments
