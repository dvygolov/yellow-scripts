# Comebacker

Попап при выходе курсора за верхнюю границу страницы.

Подключите jQuery, `comebacker/css.css` и `comebacker/script.js`. Перенесите HTML блока `#comebacker` из примера.

В `script.js` настройте задержку `3000` мс. Окно также появляется при уходе курсора за верхнюю границу страницы.

Тексты и поля задаются в HTML. Укажите свой `action` у формы; классы закрытия — `.close-over` и `.close-undermodal`.

Запуск: откройте index.html через локальный HTTP-сервер. Отправка форм заблокирована demo-common.js. Для рабочего лендинга подключите свой обработчик и удалите демонстрационный перехват.



https://github.com/dvygolov/landingscripts
https://t.me/yellow_web/57
