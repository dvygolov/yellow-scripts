# Drewlex

Набор форм, рулетки, комментариев и других элементов прелендинга.

Откройте Drewlex.JS на GitHub и выберите нужный компонент.

Подключение конкретных компонентов разобрано в отдельной статье Жёлтого Веба по ссылке ниже.

Запуск: откройте index.html через локальный HTTP-сервер. Отправка форм заблокирована demo-common.js. Для рабочего лендинга подключите свой обработчик и удалите демонстрационный перехват.



https://github.com/dvygolov/Drewlex.JS
https://yellowweb.top/kak-zamenit-komandu-verstalshhikov-odnim-skriptom-gotovyj-nabor-dlya-povysheniya-konversii-prelendingov/
