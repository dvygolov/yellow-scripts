# Двери

Три двери, выбор и показ скидки с формой.

Подключите `ywbdoors.js` и сохраните `ywbdoors.css` и папку `dimg` рядом.

Создайте отдельные контейнер игры и форму, затем вызовите `initDoors({selectors: {doors: "#doors_block", form: "#order_block"}, texts: {title: "Выберите дверь", popup: "Скидка ваша"}})`.

Запуск: откройте index.html через локальный HTTP-сервер. Отправка форм заблокирована demo-common.js. Для рабочего лендинга подключите свой обработчик и удалите демонстрационный перехват.



https://github.com/dvygolov/YWB.Doors.JS
https://t.me/yellow_web/829
