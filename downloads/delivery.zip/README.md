# Плашка доставки AD1

Уведомление о доставке в указанном городе.

Подключите jQuery, `delivery.css` и `func.js`. До скрипта задайте `landing_notifiers.params`.

Вызовите `LANDING.showDeliveryPopup()`. Город, валюта и доставка настраиваются в `city`, `currency`, `delivery_price`.

Запуск: откройте index.html через локальный HTTP-сервер. Отправка форм заблокирована demo-common.js. Для рабочего лендинга подключите свой обработчик и удалите демонстрационный перехват.



https://github.com/dvygolov/yellow-scripts/tree/main/demos/delivery
