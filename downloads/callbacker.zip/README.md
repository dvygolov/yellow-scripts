# Callbacker

Плавающая кнопка звонка и форма заявки в попапе.

Подключите `ywbcallbacker.css`, `ywbcallbacker.js` и сохраните папку `img` рядом со скриптом.

После загрузки DOM создайте `new Callbacker({texts: {...}, timeout: 500})`. В `texts` задайте `title`, `mainText`, `inputName`, `inputPhone`, `button`.

Настройте обработчик создаваемой формы. В примере кнопка открывает штатное окно обратного звонка.

Запуск: откройте index.html через локальный HTTP-сервер. Отправка форм заблокирована demo-common.js. Для рабочего лендинга подключите свой обработчик и удалите демонстрационный перехват.



https://github.com/dvygolov/YWB.Callbacker.JS
https://t.me/yellow_web/834
