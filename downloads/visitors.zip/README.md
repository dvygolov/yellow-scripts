# Панель посетителей и покупок AD1

Верхняя панель «посетителей сегодня / сейчас / покупок».

Подключите jQuery, `visitors.css` и `func.js`; положите `all.png`, `now.png`, `buy.png` рядом.

До подключения `func.js` задайте `landing_notifiers.params`, затем вызовите `LANDING.showVisitorsPanel()`. Конфигурация и стили мобильной панели приведены в `index.html`.

Запуск: откройте index.html через локальный HTTP-сервер. Отправка форм заблокирована demo-common.js. Для рабочего лендинга подключите свой обработчик и удалите демонстрационный перехват.



https://github.com/dvygolov/yellow-scripts/tree/main/demos/visitors
