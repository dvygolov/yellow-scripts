# YellowVSL

YouTube VSL-плеер: autoplay, прогресс, CTA, resume, popup и sticky.

Подключите сборку YellowVSL из GitHub или npm.

Создайте контейнер и вызовите YellowVSL.create с video и параметрами playback, ctas, sticky. Полный API и готовые конфигурации находятся на сайте YellowVSL.

Запуск: откройте index.html через локальный HTTP-сервер. Отправка форм заблокирована demo-common.js. Для рабочего лендинга подключите свой обработчик и удалите демонстрационный перехват.

Для проигрывания необходим доступ к YouTube. В примере внешнее видео загружается через YouTube API.

https://github.com/dvygolov/yellow-vsl
https://yellowvsl.pages.dev/
https://t.me/yellow_web/3675
