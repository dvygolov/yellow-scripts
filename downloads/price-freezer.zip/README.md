# Заморозка цены AD1

Виджет сохранения текущей цены.

Подключите jQuery, `freezer.css`, `func.js` и задайте `landing_notifiers.params` до `func.js`.

Вызовите `LANDING.showFreezer()`. Цена и валюта берутся из конфигурации. Для повторного показа удалите предыдущую `.freezing-wrap`, как в `index.html`.

Запуск: откройте index.html через локальный HTTP-сервер. Отправка форм заблокирована demo-common.js. Для рабочего лендинга подключите свой обработчик и удалите демонстрационный перехват.



https://github.com/dvygolov/yellow-scripts/tree/main/demos/price-freezer
